(function() {
  "use strict";

  if (navigator.userAgent.match("MSIE 10.0;")) {
    $("html").addClass("ie10");
  }

  $(document).ready(function() {

    // icons
    feather.replace();
  });

})();
